<?php include('header.php'); ?>
<div class="topSpacingHeight"></div>
<div class="BottomTopSpacing" id="plans">

<section class="contentPart">
 <div class="containerFIx-80">
   <div class="aMazingStore">
    <em>Welcome</em>
	<h1>Plans you cannot resist yourself 
from starting eCommerce business</h1>
</div>



</div>

</section>
 
   <section class="designComponent">
  <div class="container">
   <div class="CenterTXT"><h2>Regular Design Components</h2>
   <p>Mix and match a variety of Regular Design Components to create a consistent look and feel across your ecommerce website.</p></div>
 </div>
 </section>
  <section class="faqListing">
  <div class="containerFIx-80">
  
   <div class="plansTable">
    <table align="left" border="0" cellpadding="0" cellspacing="0" class="PTable" width="100%">
	 <tbody>
	  <tr class="td-right-border">
	   <td>Included in all plans</td>
	   <td>Essential</td>
	   <td>Starter</td>
	   <td>Advanced</td>
	   <td>Robust</td>
	   <td>Custom</td>
	  </tr>
	  <tr class="td-right-border">
	   <td>Unlimited Products</td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	  </tr>
	  <tr class="td-right-border" style="background:#f6f6f6;">
	   <td>Store Design Using Template</td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	  </tr>
	  <tr class="td-right-border">
	   <td>Payment Gateway Integration ( Paypal)</td>
	   <td>Paypal</td>
	   <td>Paypal  Shopify Stripe</td>
	   <td>Paypal  Shopify Stripe</td>
	   <td>Paypal  Shopify Stripe</td>
	   <td>Paypal  Shopify Stripe</td>
	  </tr>
	  <tr class="td-right-border" style="background:#f6f6f6;">
	   <td>24x7 Support</td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	  </tr>
	  <tr class="td-right-border">
	   <td>Unlimited Products</td>
	   <td>Paypal  Shopify Stripe</td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	  </tr>
	  <tr class="td-right-border" style="background:#f6f6f6;">
	   <td>Custom Theme Design</td>
	   <td></td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	  </tr>
	  <tr class="td-right-border">
	   <td>Social Media Account Setup</td>
	   <td>Available Up to $10</td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	  </tr>
	  <tr class="td-right-border" style="background:#f6f6f6;">
	   <td>Preliminary</td>
	   <td>Available Up to $10</td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	  </tr>
	  <tr class="td-right-border">
	   <td>Fulfilment Services</td>
	   <td></td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	  </tr>
	  <tr class="td-right-border" style="background:#f6f6f6;">
	   <td>Subscription Products</td>
	   <td></td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	  </tr>
	  <tr class="td-right-border">
	   <td>SEO</td>
	   <td>Available Up to $10</td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	  </tr>
	  <tr class="td-right-border" style="background:#f6f6f6;">
	   <td>Subscription Products</td>
	   <td></td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	   <td><span class="checkTableIcon"></span></td>
	  </tr>
	 </tbody> 
	</table>
   </div>
  
  </div>
</section>


</div>
<?php include('footer.php'); ?>
