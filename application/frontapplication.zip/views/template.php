<?php
$this->load->view('templates/header');
$this->load->view($v);
$this->load->view('templates/footer');
