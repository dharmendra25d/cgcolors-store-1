<?php
$this->load->view('backtemplates/header');
$this->load->view($v);
$this->load->view('backtemplates/footer');
